#ifndef __function_H
#define __function_H

#include "global.h"

/////

//////
uint8_t READ_PDU_ADRESS();
void Cal_PDU_CANID();
void ChannelAlloff();
void GetChannelVoltageStatus();
void Get_Flash_CurrentValue();





#endif
